text = input("Enter text: ")
print("Length:", len(text))
print("Reversed:", text[::-1])
