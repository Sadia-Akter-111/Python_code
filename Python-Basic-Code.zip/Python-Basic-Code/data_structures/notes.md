# Data Structures and Algorithms

- A list stores multiple values in order.
- Linear search checks items one by one: O(n).
- Binary search repeatedly halves a **sorted** search range: O(log n).
- Merge sort divides the list, sorts each half, then merges them: O(n log n).
