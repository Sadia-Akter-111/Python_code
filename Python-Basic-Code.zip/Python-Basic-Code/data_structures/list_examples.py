numbers = [5, 2, 8, 1]
print("Original:", numbers)
print("Sorted:", sorted(numbers))
print("Length:", len(numbers))
