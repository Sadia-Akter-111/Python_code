# Functions and Recursion

A function is a reusable block of code. Recursion happens when a function calls itself. Always define a base case to stop recursion.
