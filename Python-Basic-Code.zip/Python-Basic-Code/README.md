# Python Basic Code

A beginner-friendly collection of Python notes, examples, exercises, and mini projects.

## Folders
- `basics/` — variables, input/output, conditions, loops
- `functions/` — functions and recursion
- `data_structures/` — lists, strings, searching, sorting
- `mini_projects/` — small practice projects

## Run a Python file
Install Python 3, open a terminal in this folder, then run:
```bash
python basics/hello_world.py
```
