# Practice Exercises

1. Print numbers from 1 to 100.
2. Check whether a number is even or odd.
3. Find the largest of three numbers.
4. Count vowels in a string.
5. Check whether a word is a palindrome.
6. Implement selection sort.
7. Implement recursive factorial.
8. Solve a problem using binary search.
