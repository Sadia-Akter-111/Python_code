def calculator():
    a = float(input("First number: "))
    operator = input("Operator (+, -, *, /): ")
    b = float(input("Second number: "))
    if operator == "+": print(a + b)
    elif operator == "-": print(a - b)
    elif operator == "*": print(a * b)
    elif operator == "/":
        print("Cannot divide by zero." if b == 0 else a / b)
    else: print("Unknown operator")

if __name__ == "__main__":
    calculator()
