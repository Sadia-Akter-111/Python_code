# Mini Projects

Run each project with Python 3, for example:
```bash
python mini_projects/calculator.py
python mini_projects/number_guessing_game.py
```
